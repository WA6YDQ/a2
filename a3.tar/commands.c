/* commands.c - internal shell command interpreter */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "a3.h"
#include <openssl/sha.h>
//#include <openssl/conf.h>
#include <openssl/pem.h>
//#include <openssl/evp.h>
//#include <openssl/err.h>
#include <openssl/aes.h>


// external routines
extern int saveFile(char *);
extern int loadFile(char *);
extern int showfiles(int);
extern int view(char *);
extern int list();
extern int loadFile(char *);
extern int bufferstats();
extern int hash(char *);
extern int simpleSHA256(void *, unsigned long, unsigned char*);
extern int getkey(unsigned char *, unsigned char *);
extern int encr(char *);
extern int decr(char *);
extern char * base64encode(const void *, int );
extern char * base64decode(const void *, int );


// extern and global variables
extern unsigned char *buffer;
extern int pos;
unsigned char tkey[32] = {""};
unsigned char tiv[32] = {""};
int b64_decoded_bytes;



// local commands
int commands(char **args) {
    if (args[0] == NULL)    // empty command - do nothing
        return 1;

    // show directory long format
    if (strcmp(args[0],"dirl")==0) {
        showfiles(1);       // long form
        return 1;   // 1: local command
    }

    // show directory short format
    if (strcmp(args[0],"dir")==0) {
        showfiles(0);       // short form
        return 1;   // 1: local command found, do NOT test for external
    }

    // display text file contents
    if (strcmp(args[0],"view")==0) {
        view(args[1]);      // args[1] is filename
        return 1;
    }

    // show help file NOTE: make sure help.hlp is accessable
    if (strcmp(args[0],"help")==0) {
        view("help.hlp");
        return 1;
    }

	// show data in buffer
	if (strcmp(args[0],"list")==0) {
		return list();
	}

	// load a file into memory
	if (strcmp(args[0],"load")==0) {
		return loadFile(args[1]);
	}

	// save buffer to a file
	if (strcmp(args[0],"save")==0) {
		return saveFile(args[1]);
	}

	// clear data in the buffer, reset pointers
	if (strcmp(args[0],"new")==0) {
		memset((char *)buffer,0,BUFSIZE);
		pos = 0;
		printf("Buffer Cleared\n");
		return 1;
	}

	// show buffer stats 
	if (strcmp(args[0],"buffer")==0) {
		return bufferstats();
	}

	// show shell version
	if (strncmp(args[0],"ver",3)==0) {
		printf("%s build date: %s\n",VERSION,__DATE__);
		return 1;
	}

	// hash (sha256) a file
	if (strcmp(args[0],"hash")==0) {
		hash(args[1]);
		return 1;
	}

	// encrypt a file
	if (strcmp(args[0],"encr")==0) {
		encr(args[1]);
		return 1;
	}

	// decrypt a file
	if (strcmp(args[0],"decr")==0) {
		decr(args[1]);
		return 1;
	}



    return 0;   // 0: no local command found, test for external command later
}


// display data in internal buffer
int list() {
	extern unsigned char *buffer;
	extern int pos;
	for (int n=0; n<pos; n++)
		printf("%c",buffer[n]);
	return 1;
}

// show stats on internal buffer
int bufferstats() {
	printf("Buffer Used: ");
	float used=((float)pos/(float)BUFSIZE) * 100.0;		// get percent
	printf("%g %%  \n",used);
	return 1;
}

// base64 encode
char *base64encode (const void *b64_encode_this, int encode_this_many_bytes){
    BIO *b64_bio, *mem_bio;
    BUF_MEM *mem_bio_mem_ptr;
    b64_bio = BIO_new(BIO_f_base64());
    mem_bio = BIO_new(BIO_s_mem());
    BIO_push(b64_bio, mem_bio);
    BIO_set_flags(b64_bio, BIO_FLAGS_BASE64_NO_NL);
    BIO_write(b64_bio, b64_encode_this, encode_this_many_bytes);
    BIO_flush(b64_bio);
    BIO_get_mem_ptr(mem_bio, &mem_bio_mem_ptr);
    BIO_set_close(mem_bio, BIO_NOCLOSE);
    BIO_free_all(b64_bio);
    BUF_MEM_grow(mem_bio_mem_ptr, (*mem_bio_mem_ptr).length + 1);
    (*mem_bio_mem_ptr).data[(*mem_bio_mem_ptr).length] = '\0';
    return (*mem_bio_mem_ptr).data;
}

// base64 decode
char *base64decode (const void *b64_decode_this, int decode_this_many_bytes){
    extern int b64_decoded_bytes;
    BIO *b64_bio, *mem_bio;
    char *base64_decoded = calloc( (decode_this_many_bytes*3)/4+1, sizeof(char) );
    b64_bio = BIO_new(BIO_f_base64());
    mem_bio = BIO_new(BIO_s_mem());
    BIO_write(mem_bio, b64_decode_this, decode_this_many_bytes);
    BIO_push(b64_bio, mem_bio);
    BIO_set_flags(b64_bio, BIO_FLAGS_BASE64_NO_NL);
    int decoded_byte_index = 0;
    while ( 0 < BIO_read(b64_bio, base64_decoded+decoded_byte_index, 1) ){
        decoded_byte_index++;
    }
    b64_decoded_bytes = decoded_byte_index;
    BIO_free_all(b64_bio);
    return base64_decoded;
}



// simple sha256 hash
int simpleSHA256(void* input, unsigned long length, unsigned char* md)
{
    // from https://stackoverflow.com/questions/918676/generate-sha-hash-in-c-using-openssl-library
    SHA256_CTX context;
    if(!SHA256_Init(&context))
        return 0;

    if(!SHA256_Update(&context, (unsigned char*)input, length))
        return 0;

    if(!SHA256_Final(md, &context))
        return 0;

    return 1;
}


// run sha256 hash against a file
int hash(char *infile) {
	unsigned char md[32]; memset(md,0,32);
	if (infile == NULL) return 1;		// no file given
	FILE *fd = fopen(infile,"r");
	if (fd == NULL) {
		printf("%s: File not found\n",infile);
		return 1;
	}
	long fsize=0L;
	fseek(fd, 0L, SEEK_END);
	fsize = ftell(fd);
	rewind(fd);
	// load file in buffer, get hash
	unsigned char *filebuf = (unsigned char *)malloc(fsize+1);
	if (filebuf == NULL) {
		printf("Memory Error\n");
		return 1;
	}
	unsigned char ch; int fpos=0;
	while (1) {		// load file
		ch = fgetc(fd);
		if (feof(fd)) break;
		filebuf[fpos++] = ch;
	}
	fclose(fd);
	// derive hash from password
	simpleSHA256(filebuf,fsize,md);
	printf("%s : ",infile);
	for (int i=0; i<32; i++)		// print hex version of hash
		printf("%02x",md[i]);
	printf("\n");
	free(filebuf);
	return 1;
}

// ask user for password, derive key and IV
int getkey(unsigned char *key, unsigned char *IV) {
	char line[LINESIZE]; memset(line,0,LINESIZE);
	unsigned char md[32]; 
	time_t mytime;
	mytime = time(NULL);	// random counter for IV

	// get plaintext password
	printf("Password: "); fgets(line,LINESIZE-1,stdin);

	// derive hash from password
	simpleSHA256(line,strlen(line),md);
	for (int i=0; i<32; i++)
		key[i] = md[31-i];

	// derive IV from unix time
	sprintf((char *)line,"%ld",mytime);
	simpleSHA256(line,32,md);
	for (int i=0; i<32; i++)
		IV[i] = md[i];

	return 1;
}

// encrypt a file w/aes128
int encr(char *filename) {
	unsigned char *key, *IV;
	
	// point to file
	FILE *fd = fopen(filename,"r");
	if (fd == NULL) {
		printf("%s: File not found\n",filename);
		return 1;
	}

	// get file size
    fseek(fd, 0L, SEEK_END);
    long fsize = ftell(fd);
    rewind(fd);

	// make buffer for file
	unsigned char *fbuf = (unsigned char *)malloc(fsize+1);
	
	// make temp buffer for encryption
	unsigned char *tbuf = (unsigned char *)malloc(fsize+(fsize*.1));	// filesize + 10%

	// make encryption buffer
	unsigned char *ebuf = (unsigned char *)malloc(33+fsize+(fsize*.1));	// filesize + 10% + IV

	// test buffers
	if (fbuf == NULL || tbuf == NULL || ebuf == NULL) {
		printf("Memory error - aborting\n");
		free(fbuf); free(tbuf); free(ebuf);
		return 1;
	}
	memset(fbuf,0,fsize);
	memset(tbuf,0,fsize+(fsize*.1));
	memset(ebuf,0,33+fsize+(fsize*.1));

	// read file into buffer
	unsigned char ch; long int fpos=0L;
	while (1) {
		ch = fgetc(fd);
		if (feof(fd)) break;
		fbuf[fpos++] = ch;
	}
	fclose(fd);

	// get password from user
	key = tkey; IV = tiv;
	memset(tiv,0,32);
	getkey(key,IV);

	// data structure for the key 
	AES_KEY aeskey;

	/* set the encryption key */
    AES_set_encrypt_key(key, 128, &aeskey);

	/* set where on the 128 bit encrypted block to begin encryption*/
    int num = 0;

	// prepend the IV to the ebuf;
    for (int i=0; i<32; i++) ebuf[i] = IV[i];

	// encrypt fbuf to tbuf
    AES_cfb128_encrypt(fbuf, tbuf, fsize, &aeskey, IV, &num, AES_ENCRYPT);

	// append tbuf to ebuf
	for (int i=0; i<fsize; i++) ebuf[i+32] = tbuf[i];

	free(fbuf);
	free(tbuf);
	
	// aes encrypted file is in ebuf. size is fsize+32
	char *base64_encoded = base64encode(ebuf,fsize+32L);

	// now save the encoded data
	char line[LINESIZE];
	memset(line,0,LINESIZE);
	printf("File name for encrypted file: ");
	fgets(line,LINESIZE,stdin);
	line[strlen(line)-1] = '\0';		// remove \n
	fd = fopen(line,"w");
	if (fd == NULL) {
		printf("%s: Error creating file\n",line);
		free(ebuf);
		return 1;
	}
	for (unsigned int i=0; i<strlen(base64_encoded); i++) fprintf(fd,"%c",base64_encoded[i]);
	fclose(fd);
	
	free(ebuf);
	printf("File encrypted\n");
	return 1;
}


// decrypt file with aes128
int decr(char *filename) {
	unsigned char *key, *IV;

	// point to file
	// point to file
	FILE *fd = fopen(filename,"r");
	if (fd == NULL) {
		printf("%s: File not found\n",filename);
		return 1;
	}

	// get file size
	long fsize=0L;
    fseek(fd, 0L, SEEK_END);
    fsize = ftell(fd);
    rewind(fd);

	// make buffer for file
	unsigned char *fbuf = (unsigned char *)malloc(fsize+1);

	// make buffer for decryption
	unsigned char *dbuf = (unsigned char *)malloc(fsize+1);

	unsigned char *tbuf = (unsigned char *)malloc(fsize+1);

	// make buffer for plaintext
	unsigned char *pbuf = (unsigned char *)malloc(fsize+1);

	// test buffers
	if (fbuf == NULL || dbuf == NULL || pbuf == NULL || tbuf == NULL) {
		printf("Memory error - aborting\n");
		free(fbuf); free(dbuf); free(pbuf); free(tbuf);
		fclose(fd);
		return 1;
	}

	// read the file into the fbuf buffer
	char ch; int i=0;
	while (1) {
		ch = fgetc(fd);
		if (feof(fd)) break;
		fbuf[i++] = ch;
	}
	fclose(fd);

	// convert base64 to aes encrypted
	char *base64_decoded = base64decode(fbuf,fsize);
	int dpos = b64_decoded_bytes;
	
	memset(dbuf,0,fsize+1);
	memcpy(dbuf,base64_decoded,dpos);

	// get password from user
    key = tkey; IV = tiv;
    getkey(key,IV);		// we don't use the IV here

	// get the IV from dbuf
    memset(IV,0,32);
	for (int i=0; i<32; i++) IV[i] = dbuf[i];

	memset(tbuf,0,fsize+1);

	// copy dbuf minus the IV to tbuf
    for (int i=0; i<dpos-32; i++) tbuf[i] = dbuf[i+32];	// was dpos-32
	
	// prepare aes decryption
	
	/* data structure that contains the key itself */
    AES_KEY aeskey;

	/* set the encryption key */
    AES_set_encrypt_key(key, 128, &aeskey);

	/* set where on the 128 bit encrypted block to begin encryption*/
    int num = 0;

	AES_cfb128_encrypt(tbuf, pbuf, dpos, &aeskey, IV, &num, AES_DECRYPT);
    dpos -= 32;

	// display plain text buffer
	for (int i=0; i<dpos; i++) printf("%c",pbuf[i]);
	printf("\n");

	printf("File name for decrypted data (.q to abort save): ");
	char line[LINESIZE] = {""};
	fgets(line,LINESIZE, stdin);
	if (strncmp(line,".q",2)!=0) {		// save file
		line[strlen(line)-1] = '\0';	// remove \n
		fd = fopen(line,"w");
		if (fd == NULL) {
			printf("%s: Error creating file\n",line);
		} else {
			for (int i=0; i<dpos; i++) 
				fprintf(fd,"%c",pbuf[i]);
			fclose(fd);
		}
	}

	// clear buffers
	free(dbuf);
	free(tbuf);
	free(fbuf);

	return 1;
}





