#define BUFSIZE 100000
#define LINESIZE 81
#define VERSION "version 0.1 "

/* ANSI colors for terminal
 *
 * The codes for foreground and background colours are:

         foreground background
black        30         40
red          31         41
green        32         42
yellow       33         43
blue         34         44
magenta      35         45
cyan         36         46
white        37         47

reset             0  (everything back to normal)
bold/bright       1  (often a brighter shade of the same colour)
underline         4
inverse           7  (swap foreground and background colours)
bold/bright off  21
underline off    24
inverse off      27

 cout << "\033[1;31mbold red text\033[0m\n";

Here, \033 is the ESC character, ASCII 27. 
It is followed by [, then zero or more numbers separated 
by ;, and finally the letter m. The numbers describe the 
colour and format to switch to from that point onwards.

*/

#define FG_RED 31
#define FG_YELLOW 33
#define FG_GREEN 32
#define FG_BLUE 34
#define FG_WHITE 37

#define RED \033[1;31m
#define WHITE \033[1;37m
#define YELLOW \033[1;33m
#define GREEN \033[1;32m
#define BLUE \033[1;34m

