/*
 * this is a really simple little shell program
 * (C) 2022 k. theis <theis.kurt@gmail.com> 
 *
 * uses gnu readline for a better user experience
 * test internal commands, and if nothing found, test
 * unix commands in /bin, /usr/bin, etc
 * there is NO wildcard expansion (* or ?)
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <wait.h>
#include <errno.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "a3.h"

#define PROMPT "\033[1;32mcmd> \033[1;0m"		// green text, returning to normal
#define TOK_BUFSIZE 64
#define TOK_DELIM " \t\r\n\a"

// globals
unsigned char *buffer;
unsigned int pos=0;		// buffer position
char **tokens;
char *line_read = NULL;		// GNU readline()

// external routines
extern int commands(char **);



// prepare to exit
int quit(void) {
	free(buffer);
	free(tokens);
	return 0;
}



// split line into tokens
char **split_line(char *line) {
	int bufsize = TOK_BUFSIZE, position=0;
	// note: tokens free()'d in main()
	tokens = (char **)malloc(bufsize * sizeof(char *));
	char *token;

	if (!tokens) {
		fprintf(stderr,"token parse: allocation error\n");
		exit (1);
	}
	token = strtok((char *)line, TOK_DELIM);
	while (token != NULL) {
		tokens[position] = token;
		position++;
		
		if (position >= bufsize) {
			bufsize += TOK_BUFSIZE;
			tokens = realloc(tokens, bufsize*sizeof(char *));
			if (!tokens) {
				fprintf(stderr,"token parse: allocation error\n");
				exit (1);
			}
		}
		token = strtok(NULL, TOK_DELIM);
	}
	tokens[position] = NULL;
	return tokens;
}




// execute tokens as a command line to unix
int execute(char **args) {
	pid_t pid, wpid;
	int status = 0;

	if (args[0] == NULL) 		// empty command - do nothing 
		return 1;

	pid = fork();
	if (pid == 0) {	// child process
		if (execvp(args[0], args) == -1) {
			perror(args[0]);
		}
		exit(1);
	} else if (pid < 0) {	// error forking
		perror("fork error");
	} else {	// parent process
		do {
				// wait until the child exits
				wpid = waitpid(pid, &status, WUNTRACED);
				if (wpid == -1) perror("fork");
			} while (!WIFEXITED(status) && !WIFSIGNALED(status));
	}
	
	// handle segfaults, etc
	if (status == 11) {
		printf("Error 11 Segfault\n");
	} else if (status > 0) {
		//printf("System Error %d %s\n",status,strerror(status));
	} // don't show normal return of 0

	return 0;
}



// use GNU readline() to get a line from the user
char *rl_gets() {

	if (line_read) {	// if not empty, free it up
		free(line_read);
		line_read = (char *)NULL;
	}
	line_read = readline(PROMPT);	// PROMPT is a define
	if (line_read && *line_read)
		add_history(line_read);		// add to history is != 0

	return (line_read);
}


/* ************ */
/* *** MAIN *** */
/* ************ */

int main(void) {

	char **args;
	int rc = 0;

	buffer = (unsigned char *)malloc(BUFSIZE);
	if (buffer == NULL) {
		fprintf(stderr,"Fatal: memory error\n");
		return 1;
	}
	memset(buffer,0,BUFSIZE); pos = 0;

	
	// command loop
	while (1) {
	
		/* use GNU readline() to get a line from the user terminal 
		 * returned line is in line_read, PROMPT is printed first 
		 */ 
		rl_gets();

		// parse line into tokens
        args = split_line(line_read); 
		if (args[0] == NULL) continue;		// ignore user hitting <enter> by itself

		/* commands given are one of three kinds - 
		 * high level (execute immediately here)
		 * built-in commands (routines local to this shell)
		 * unix commands (in /bin, /sbin, etc)
		 *
		 * test each, run and return any status needed
		 */
	
		// high-level tests
		if (strcmp(args[0],"quit")==0 || strcmp(args[0],"exit")==0) {
			quit();
			exit(0);
		}

		if (strcmp(args[0],"cls")==0) {
			printf("\033c");	// clear the terminal screen
			continue;
		}

		if (strcmp(args[0],"reload")==0 && args[1]==NULL) {		// restart the shell
			strcpy(args[0],"./a3");
			fprintf(stderr,"Restarting\n");
			execv(args[0],args);
		}

		// test if commands are local (in commands.c)
		rc = commands(args);	// commands() returns 1 on success, 0 is not found
		if (rc) {
			free(tokens);
			continue;	// command(s) executed locally - continue loop
		}

		// else execute the args as commands
		rc = execute(args);
		free(tokens);
		if (rc)
			printf("Execution Error\n");
		continue;

		// nothing else to do
	}

	fprintf(stderr,"Fatal - command loop exited\n");
	exit(1);		// should never get here

}
