#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glob.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/sysmacros.h>
#include <unistd.h>
#include <pwd.h>
#include "a3.h"

extern unsigned char *buffer;
extern int pos;

// load a file into memory buffer
int loadFile(char *filename) {
	FILE *fd = fopen((char *)filename,"r");
    if (fd == NULL) {
        printf("File %s not found\n",filename);
        return 1;
    }
    memset(buffer,0,BUFSIZE);   // first clear the buffer, set pos to 0
    unsigned char ch; pos = 0;
    while (1) {
        ch = fgetc(fd);
        if (feof(fd)) break;
        buffer[pos++] = ch;
    }
    fclose(fd);
    printf("Read in %d characters\n",pos);
    return 1;
}

// save memory buffer to a file
int saveFile(char *filename) {
    FILE *fd = fopen((char *)filename,"w");
    if (fd == NULL) {
        printf("File %s not created\n",filename);
        return 1;
    }

	int n=0;
	for (n=0; n<pos; n++) 
		fprintf(fd,"%c",buffer[n]);

	fflush(fd);
	fclose(fd);
    printf("Wrote %d characters\n",n);
    return 1;
}

int showfiles(int f) {
	extern int filedetail(char *);
	glob_t globlist;
	int i=0;
	// by using *, . and .. will ALWAYS be found, so NOMATCH is an error
	int retval = glob("*", GLOB_PERIOD, NULL, &globlist);
    if (retval == GLOB_NOSPACE || \
		 retval == GLOB_ABORTED || \
		 retval == GLOB_NOMATCH) {
		printf("glob() error: Aborted.\n");
        globfree(&globlist);
		return 1;
    }
	printf("Files:\n");
	while (globlist.gl_pathv[i]) {
		// short form, only files (no dirs)
		if (i > 1) 	// don't show . or ..
			if (f==0) printf("%s\n",globlist.gl_pathv[i]);
		// long form, show all (files & dirs)
		if (f==1) filedetail(globlist.gl_pathv[i]);
		i++;
	}
	globfree(&globlist);
	printf("\n");
	return 0;
}

int filedetail(char *fname) {
	struct stat sb;			// pulled from man 2 stat
	struct passwd *pw;
	if (lstat(fname, &sb)==-1) {
		perror("lstat");
		return(EXIT_FAILURE);
	}
	// file owner
	pw = getpwuid(sb.st_uid);
	printf("%s",pw->pw_name);	
	// file group
	pw = getpwuid(sb.st_gid);
	printf("%8s\t",pw->pw_name);
	// file size (bytes)
	printf("%lld\t%s\n",(long long)sb.st_size, fname);
	return 0;
}

int view(char *filename) {

	FILE *fd = fopen(filename,"r");
	if (fd == NULL) {
		perror("view");
		return 1;
	}
	char ch;
	while (1) {
		ch = fgetc(fd);
		if (feof(fd)) break;
		printf("%c",ch);
	}
	fclose(fd);
	return 0;
}
